# Usage

### Front-end

1. Drag selected component to your page
2. Configure parameters
3. Override component HTML with your form | ([more info](https://octobercms.com/docs/cms/components#overriding-partials))
4. Ready