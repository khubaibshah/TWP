# Validation

Form validation is independent for every component.

Just use [Laravel validation rules](https://laravel.com/docs/5.1/validation#available-validation-rules) as usual.

You can use as many as you want: ```required|alpha``` or ```required|email```