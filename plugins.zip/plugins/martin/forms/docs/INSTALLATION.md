# Installation

In your OctoberCMS backend, go to Updates > Install plugins and search for "martin.forms"

**Alternative #1:** install from [October Marketplace](https://octobercms.com/plugins)

**Alternative #2:** from console, run: `php artisan plugin:install Martin.Forms`